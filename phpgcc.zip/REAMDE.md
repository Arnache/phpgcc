# phpgcc
phpgcc is a library that I designed to decrease boilerplate coding in my command-line programs that create PNG or EPS images, or sequences of PNG images. I used it for long periods on the three main systems: Windows via Cygwin, Mac, Linux.

See the manual.

# Disclaimer
This code is provided as-is without any guarantee of any sort. In now way the author can be liable for any damage it may induce.

# Licence 
CC BY-SA 4.0 Arnaud Chéritat

# Author
Arnaud Chéritat 
