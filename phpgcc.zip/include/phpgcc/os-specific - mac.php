<?php

$os="mac";
$extension=".mac.exe";
$include_path="/usr/local/include";
$more_paths="-L/opt/local/lib -I/opt/local/include";
$gpp="g++-mp-4.9";
$lib_name = "phpgcc";

?>
