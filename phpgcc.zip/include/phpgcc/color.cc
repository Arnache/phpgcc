typedef struct {
  double red;
  double green;
  double blue;
} color;
