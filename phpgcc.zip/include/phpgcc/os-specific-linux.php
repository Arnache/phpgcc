<?php

$os="linux";
$extension=".linux.exe";
$include_path="/usr/local/include";
$more_paths="";
$gpp="g++";
$lib_name = "phpgcc";

?>
