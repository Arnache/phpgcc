<?php

$os="cygwin";
$extension=".win.exe";
$include_path="/usr/local/include";
$more_paths="";
$gpp="g++";
$lib_name = "phpgcc";

?>
